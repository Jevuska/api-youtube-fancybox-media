<form method="get" action="<?php echo trailingslashit( home_url() ); ?>">
      <input class="input" type="text" name="s" value="<?php if ( is_search() ) echo esc_attr( get_search_query() ); else esc_attr_e( 'Search Video...'); ?>" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"/>
      <select name="o">
      <option value="relevance">Relevance</option>
      <option value="published">Publication time</option>
      <option value="viewCount">User views</option>
      <option value="rating">User rating</option>
      </select>
      <select name="i">
        <option value="10">10</option>
        <option value="25">25</option>
        <option value="50">50</option>
        <option value="100">100</option>
      </select>
      <input type="submit" value="search"/>  
</form>
 <?php
      if (!isset($_GET['s']) || empty($_GET['s'])) {
        die ('ERROR: Please enter one or more search keywords');
      } else {
        $s = $_GET['s'];
        $s = ereg_replace('[[:space:]]+', ' ', trim($s));
        $s = urlencode($s);
      }
      if (!isset($_GET['o']) || empty($_GET['o'])) {
        $o = 'viewCount';
      } else {
        $o = htmlentities($_GET['o']);
      }
      if (!isset($_GET['i']) || empty($_GET['i'])) {
        $i = 25;
      } else {
        $i = htmlentities($_GET['i']);
      }
      if (!isset($_GET['pageID']) || $_GET['pageID'] <= 0) {
        $t = 1;  
      } else {        
        $pageID = htmlentities($_GET['pageID']);
        $t = (($pageID-1) * $i)+1;  
      }


    // Setting URL Feed
    $ytfeedURL = 'https://gdata.youtube.com/feeds/api/videos?q='.$s.'&orderby='.$o.'&max-results='.$i.'&start-index='.$t.'&v=2';
    $ytxml = simplexml_load_file($ytfeedURL);
    ?>
      <h1><?php echo $ytxml->title; ?></h1>
    <?php
    foreach ($ytxml->entry as $entry) {
      $media = $entry->children('http://search.yahoo.com/mrss/');
      $attrs = $media->group->player->attributes();
      $watch = $attrs['url']; 
      $attrs = $media->group->content->attributes();
      $player = $attrs['url']; 
      $attrs = $media->group->thumbnail[2]->attributes();
      $thumbnail = $attrs['url']; 
      $yt = $media->children('http://gdata.youtube.com/schemas/2007');
      $attrs = $yt->duration->attributes();
      $length = $attrs['seconds']; 
      $yv = $entry->children('http://gdata.youtube.com/schemas/2007');
      if ($yv->statistics) {
        $attrs = $yv->statistics->attributes();
        $viewCount = $attrs['viewCount']; 
      } else {
        $viewCount = 0; 
      } 
     
      $gd = $entry->children('http://schemas.google.com/g/2005'); 
      if ($gd->rating) {
        $attrs = $gd->rating->attributes();
        $rating = $attrs['average']; 
      } else {
        $rating = 0; 
      } 
      ?>
      <div class="item">
        <span class="title">
          <a class="fancybox-media" href="<?php echo $watch; ?>"><?php echo $media->group->title; ?></a>
        </span>

        <p><?php echo $media->group->description; ?></p>
        <p>
          <span class="thumbnail">
            <a class="fancybox-media" href="<?php echo $player; ?>"><img src="<?php echo $thumbnail;?>" /></a>
            <br/>
            Click to play
            <br/>
          </span>
<span class="attr">Duration:</span> <?php printf('%0.2f', $length/60); ?> min. | <span class="attr">Rating:</span> <?php echo $rating; ?> | <span class="attr">Views:</span> <?php echo $viewCount; ?> | <span class="attr">By:</span> <?php echo $entry->author->name; ?>        
        </p>
      </div>      
    <?php
    }
    ?>