//setting video YouTube
jQuery(document).ready(function() {
			$('.fancybox-media')
				.fancybox({
					openEffect : 'none',
					closeEffect : 'none',
					prevEffect : 'none',
					nextEffect : 'none',
					width	: 500,
					height: 400,
					arrows : false,
					helpers : {
						media : {},
						buttons : {}
					}
				});
//disable right click
        $('img').live('contextmenu', function(e){e.preventDefault();});
});